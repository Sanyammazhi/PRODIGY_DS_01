library(ggplot2)
library(readxl)
library(Hmisc)

#df <- read.csv("~/Documents/Data Science/R/Code/Titanic Data Set/titanic.csv")

df<- read_xlsx("~/Documents/ITM/courses/Workshop on R/titanic.xlsx")
head(df,10)
str(df)

df[2,]
df[1:5,]
df[,6]
df[,6:8]
df[3:5,1:5]

#check for NA
sum(is.na(df))
names(which(colSums(is.na(df)) > 0))
which(is.na(df$embarked))
df[169,]

df <- na.omit(df)

#convert to categorical variables
df$survived <- as.factor(df$survived)
df$pclass <- as.factor(df$pclass)
df$gender <- as.factor(df$gender)
df$embarked <- as.factor(df$embarked)

levels(df$survived)
levels(df$gender)
levels(df$pclass)
nlevels(df$embarked)

#recode levels
levels(df$survived) <- c("No","Yes")

##summary 
summary(df)
summary(df$survived)

## create a new column
df$accident_year <- 1912

## conditional subsetting of a dataframe
df_2 <- subset(df, embarked == "S")

#check how many levels are there??
summary(df_2$embarked)
nlevels(df_2$embarked)

## get those levels correct
df_2$embarked <- factor(df_2$embarked)
summary(df_2$embarked)
nlevels(df_2$embarked)


#summary by groups
by(df, df$survived, summary)
by(df, df$pclass, summary)

### more descriptive stats
library(pastecs)
stat.desc(df)           ## is it correct?

stat.desc(Filter(is.numeric, df))


#### imputation
sum(is.na(df$age))
df$age <- impute(df$age, fun = mean)
which(is.imputed(df$age))


## tables with categorical variables
table(df$survived, df$pclass)
barplot(table(df$survived, df$pclass), legend.text = TRUE) ## plot it

table(df$survived, df$gender)

# table for 3 variables
xtabs(~survived+pclass+gender, data = df)

## table with continuous variables
aggregate(fare ~ survived, data = df,FUN = mean)
aggregate(age ~ survived, data = df,FUN = median)

# loops and conditions in R

## if else
if(df$age < 18)
  {
    print("Minor")
  }else
  {
    print("Adult")
  }
  
ifelse(df$age<18,print("Minor"), print("Adult"))

## for loop
for (i in 1:5)
{
  print(df[i,3])
}

## while loop
i = 1
while (i <= 5) {
  print(df[i,3])
  i = i + 1
}


## some more plotting with ggplot
ggplot(data = df, aes(survived,fare)) + geom_boxplot()
ggplot(data = df, aes(fare, age)) + geom_point()
ggplot(data = df, aes(survived,pclass)) + geom_bar()
ggplot(df, aes(pclass, ..count..)) + geom_bar(aes(fill = survived), position = "dodge")
ggplot(df, aes(x=factor(pclass))) +
  geom_bar(aes(fill=factor(survived), y=..count.., group=factor(survived)), position="dodge") +
  facet_wrap(~factor(gender))


# model ad_sales
ad_sales <- read_excel("~/Documents/IIT SOM/TA Duty/Predictive Analytics 2022/ad_sales.xls")
model_adSales <- lm(ad_sales$Sales_thousands~ad_sales$Ad_Exp_Lakhs*ad_sales$Price)
summary(model_adSales)

par(mfrow=c(2,2))
plot(model_adSales)
par(mfrow = c(1,1))
#####


